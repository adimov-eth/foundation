---
name: tmux-orchestration
description: Control interactive terminal processes via tmux-cli - launch CLI applications, send input, capture output, wait for completion. This skill should be used when tasks require interactive debugging (pdb, node inspect), REPL exploration, long-running observable processes, or spawning another Claude instance for independent analysis or second opinions.
---

# Tmux Orchestration

## Overview

This skill enables programmatic control of interactive terminal applications through tmux panes. It bridges the gap between Claude's request/response model and processes that require back-and-forth interaction.

**Prerequisite**: `tmux-cli` must be installed (`uv tool install claude-code-tools`).

## When to Use This Skill

Use tmux orchestration when:
- **Interactive debugging** - Step through code with pdb/node inspect, observe state, decide next action
- **REPL exploration** - Iterative code refinement beyond simple execution
- **Another Claude instance** - Fresh perspective, specialized focus, or reasoning verification
- **Observable long-running processes** - Dev servers where logs need monitoring while working

Do NOT use when:
- Simple command execution suffices (use Bash directly)
- No interactivity needed (output is final, no decisions based on it)
- Time-sensitive operations (tmux adds latency)

## Core Commands

```bash
# Launch application in new pane (returns pane identifier)
tmux-cli launch "command"

# Send input to pane
tmux-cli send "text" --pane=PANE_ID

# Capture current output
tmux-cli capture --pane=PANE_ID

# Wait for output to stabilize (no changes for N seconds)
tmux-cli wait_idle --pane=PANE_ID --idle-time=2.0

# Send Ctrl+C
tmux-cli interrupt --pane=PANE_ID

# Close pane
tmux-cli kill --pane=PANE_ID

# Show all panes
tmux-cli status
```

## Critical Pattern: Launch Shell First

**Always launch a shell before running commands.** If a command errors, the pane closes immediately and output is lost.

```bash
# CORRECT - preserves output on errors
tmux-cli launch "zsh"
# Returns: session:window.pane (e.g., "main:1.2")
tmux-cli send "python script.py" --pane=main:1.2

# WRONG - loses output if script fails
tmux-cli launch "python script.py"
```

## Workflows

For detailed workflow patterns, see [references/workflows.md](references/workflows.md).

### Quick Reference

**Interactive Debugging (pdb)**:
1. Launch shell → 2. Start debugger → 3. Send commands (n/s/p) → 4. Capture state → 5. Decide next step

**Claude-to-Claude Communication**:
1. Launch `claude` → 2. Send focused prompt → 3. `wait_idle` → 4. Capture response → 5. Integrate or respond

**REPL Exploration**:
1. Launch shell → 2. Start REPL → 3. Send expression → 4. Capture result → 5. Refine based on output

## Avoiding Common Mistakes

1. **Don't poll** - Use `wait_idle` instead of repeated `capture`
2. **Don't forget the shell** - Direct command launch loses error output
3. **Don't kill your own pane** - tmux-cli prevents this, but be aware
4. **Do save pane identifiers** - Store the returned identifier from `launch`
