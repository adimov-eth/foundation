# Tmux Orchestration Workflows

Detailed patterns for interactive terminal orchestration.

## Interactive Debugging with pdb

Step through Python code, observe state at each point, make decisions based on what you see.

### Setup

```bash
# 1. Launch shell
PANE=$(tmux-cli launch "zsh")
echo "Debug pane: $PANE"

# 2. Start debugger
tmux-cli send "python -m pdb script.py" --pane=$PANE

# 3. Wait for pdb prompt
tmux-cli wait_idle --pane=$PANE --idle-time=1.0
```

### Debugging Commands

```bash
# Step to next line
tmux-cli send "n" --pane=$PANE

# Step into function
tmux-cli send "s" --pane=$PANE

# Print variable
tmux-cli send "p variable_name" --pane=$PANE

# Print locals
tmux-cli send "pp locals()" --pane=$PANE

# Continue to next breakpoint
tmux-cli send "c" --pane=$PANE

# Set breakpoint
tmux-cli send "b filename:lineno" --pane=$PANE

# Where am I (stack trace)
tmux-cli send "w" --pane=$PANE
```

### Pattern: Investigate → Decide → Act

```bash
# After each step, capture and analyze
tmux-cli send "n" --pane=$PANE
tmux-cli wait_idle --pane=$PANE --idle-time=0.5
OUTPUT=$(tmux-cli capture --pane=$PANE --lines=20)

# Analyze OUTPUT, then decide:
# - "n" to continue stepping
# - "p var" to inspect something
# - "s" to dive into a function
# - "c" to continue to breakpoint
```

### Cleanup

```bash
tmux-cli send "q" --pane=$PANE  # Quit pdb
tmux-cli send "exit" --pane=$PANE  # Exit shell
tmux-cli kill --pane=$PANE
```

---

## Claude-to-Claude Communication

Spawn another Claude instance for independent analysis, fresh perspective, or specialized focus.

### When to Spawn Another Instance

**Good reasons:**
- Need fresh perspective without accumulated context bias
- Want independent verification of reasoning
- Specialized subtask that benefits from focused attention
- Code review by "another set of eyes"

**Bad reasons:**
- Task is simple enough to do directly
- Context carryover is important (spawned instance has none)
- Time-sensitive (startup adds ~3-5 seconds)

### Basic Pattern

```bash
# 1. Launch Claude in new pane
CLAUDE_PANE=$(tmux-cli launch "zsh")
tmux-cli send "claude" --pane=$CLAUDE_PANE

# 2. Wait for Claude to start
tmux-cli wait_idle --pane=$CLAUDE_PANE --idle-time=3.0

# 3. Send focused prompt
tmux-cli send "Review this function for edge cases:

def process_items(items):
    return [x * 2 for x in items if x > 0]

What inputs might cause unexpected behavior?" --pane=$CLAUDE_PANE

# 4. Wait for response to complete
tmux-cli wait_idle --pane=$CLAUDE_PANE --idle-time=5.0

# 5. Capture response
RESPONSE=$(tmux-cli capture --pane=$CLAUDE_PANE)

# 6. Cleanup
tmux-cli send "/exit" --pane=$CLAUDE_PANE
tmux-cli wait_idle --pane=$CLAUDE_PANE --idle-time=1.0
tmux-cli kill --pane=$CLAUDE_PANE
```

### Prompt Design for Spawned Instances

The spawned Claude has NO context. The prompt must be self-contained.

**Include:**
- Complete code/data being analyzed
- Specific question or task
- Expected output format
- Constraints or requirements

**Example - Code Review:**
```
Review this TypeScript function for:
1. Type safety issues
2. Edge cases
3. Performance concerns

```typescript
function merge<T>(a: T[], b: T[]): T[] {
  return [...a, ...b].sort();
}
```

List findings as bullet points with severity (high/medium/low).
```

**Example - Reasoning Verification:**
```
I concluded that the bug is in the authentication middleware because:
1. Error only occurs on protected routes
2. Token validation passes in unit tests
3. Middleware logs show the request stops there

Do you agree with this analysis? What alternative explanations exist?
```

### Multi-Turn Interaction

For complex analysis requiring follow-up:

```bash
# Initial prompt
tmux-cli send "Analyze this architecture diagram..." --pane=$CLAUDE_PANE
tmux-cli wait_idle --pane=$CLAUDE_PANE --idle-time=5.0

# Capture and analyze response
RESPONSE=$(tmux-cli capture --pane=$CLAUDE_PANE)

# Follow-up based on response
tmux-cli send "You mentioned scalability concerns. Can you elaborate on the database bottleneck?" --pane=$CLAUDE_PANE
tmux-cli wait_idle --pane=$CLAUDE_PANE --idle-time=5.0
```

---

## REPL Exploration

Iterative code development and exploration in Python, Node, or other REPLs.

### Setup

```bash
# Python
PANE=$(tmux-cli launch "zsh")
tmux-cli send "python3" --pane=$PANE
tmux-cli wait_idle --pane=$PANE --idle-time=1.0

# Node
PANE=$(tmux-cli launch "zsh")
tmux-cli send "node" --pane=$PANE
tmux-cli wait_idle --pane=$PANE --idle-time=1.0
```

### Exploration Pattern

```bash
# Send expression
tmux-cli send "import pandas as pd" --pane=$PANE
tmux-cli wait_idle --pane=$PANE --idle-time=0.5

tmux-cli send "df = pd.read_csv('data.csv')" --pane=$PANE
tmux-cli wait_idle --pane=$PANE --idle-time=1.0

tmux-cli send "df.head()" --pane=$PANE
tmux-cli wait_idle --pane=$PANE --idle-time=0.5

# Capture to see result
OUTPUT=$(tmux-cli capture --pane=$PANE --lines=30)
# Analyze OUTPUT, decide next exploration step
```

### Multi-line Code

For multi-line code in Python REPL:

```bash
# Use triple quotes or continuation
tmux-cli send "def process(x):" --pane=$PANE
tmux-cli send "    return x * 2" --pane=$PANE
tmux-cli send "" --pane=$PANE  # Empty line to end definition
```

---

## Long-Running Observable Processes

Monitor dev servers, build processes, or test runs while doing other work.

### Pattern: Launch and Monitor

```bash
# Launch dev server
SERVER_PANE=$(tmux-cli launch "zsh")
tmux-cli send "npm run dev" --pane=$SERVER_PANE

# Periodically check for issues
# (Usually triggered by user request or after making changes)
LOGS=$(tmux-cli capture --pane=$SERVER_PANE --lines=50)
# Analyze for errors, warnings, or relevant output
```

### Pattern: Watch for Specific Output

```bash
# After making a change, check if server shows errors
tmux-cli capture --pane=$SERVER_PANE --lines=20

# Look for patterns like:
# - "Error:", "error:", "ERROR"
# - "Warning:", "WARN"
# - "compiled successfully"
# - Stack traces
```

---

## Error Handling

### Pane Disappeared

If a pane closes unexpectedly:
```bash
# Check status
tmux-cli status

# List all panes to find alternatives
tmux-cli list_panes
```

### Process Hung

```bash
# Send interrupt
tmux-cli interrupt --pane=$PANE

# If still unresponsive, force kill
tmux-cli kill --pane=$PANE
```

### Lost Pane Identifier

```bash
# Find panes by examining what's running
tmux-cli status
# Shows: session:window.pane  command  title

# Use the formatted identifier from status output
```
